
import java.util.Scanner;

public class Calcv0 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a math expression: ");
        String expression = scanner.nextLine();
        double result = evaluate(expression);
        System.out.println("Result: " + result);
    }

    public static double evaluate(String expression) {
        expression = expression.replaceAll(" ", "");
        return evaluateExpression(expression);
    }

    private static double evaluateExpression(String expression) {
        if (expression.contains("(")) {
            int openIndex = expression.lastIndexOf("(");
            int closeIndex = expression.indexOf(")", openIndex);
            String innerExpression = expression.substring(openIndex + 1, closeIndex);
            double innerResult = evaluateExpression(innerExpression);
            expression = expression.substring(0, openIndex) + innerResult + expression.substring(closeIndex + 1);
            return evaluateExpression(expression);
        } else if (expression.contains("^")) {
            int index = expression.indexOf("^");
            String left = expression.substring(0, index);
            String right = expression.substring(index + 1);
            double leftValue = evaluateTerm(left);
            double rightValue = evaluateFactor(right);
            return Math.pow(leftValue, rightValue);
        } else {
            return evaluateTerm(expression);
        }
    }

    private static double evaluateTerm(String expression) {
        if (expression.contains("*")) {
            int index = expression.indexOf("*");
            String left = expression.substring(0, index);
            String right = expression.substring(index + 1);
            double leftValue = evaluateTerm(left);
            double rightValue = evaluateFactor(right);
            return leftValue * rightValue;
        } else if (expression.contains("/")) {
            int index = expression.indexOf("/");
            String left = expression.substring(0, index);
            String right = expression.substring(index + 1);
            double leftValue = evaluateTerm(left);
            double rightValue = evaluateFactor(right);
            return leftValue / rightValue;
        } else {
            return evaluateFactor(expression);
        }
    }

    private static double evaluateFactor(String expression) {
        if (expression.contains("+")) {
            int index = expression.indexOf("+");
            String left = expression.substring(0, index);
            String right = expression.substring(index + 1);
            double leftValue = evaluateFactor(left);
            double rightValue = evaluateTerm(right);
            return leftValue + rightValue;
        } else if (expression.contains("-")) {
            int index = expression.indexOf("-");
            String left = expression.substring(0, index);
            String right = expression.substring(index + 1);
            double leftValue = evaluateFactor(left);
            double rightValue = evaluateTerm(right);
            return leftValue - rightValue;
        } else {
            return Double.parseDouble(expression);
        }
    }
}