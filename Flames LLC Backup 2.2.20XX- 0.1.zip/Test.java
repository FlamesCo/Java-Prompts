public class Test {
	public static void main(String[] args) {
	System.out.println("Hello world");   // Display the string

	System.out.println("Hello world 2");   // Display the string
 } }